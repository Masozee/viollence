from rest_framework import serializers
from apps.web.models import *

class OptionsSerializer(serializers.ModelSerializer):
    class Meta:
        model = Options
        fields = '__all__'

class CasualitiesSerializer(serializers.ModelSerializer):
    class Meta:
        model = Casualities
        fields = '__all__'

class IncidentsSerializer(serializers.ModelSerializer):
    casualities = CasualitiesSerializer(source='Incident_casualities', many=True, read_only=True)

    class Meta:
        model = Incidents
        fields = '__all__'

class DataValueSerializer(serializers.ModelSerializer):
    region = serializers.StringRelatedField()
    area_code = serializers.CharField(source='region.area_code')
    total_value = serializers.SerializerMethodField()

    class Meta:
        model = DataValue
        fields = ['region','area_code', 'total_value',]

    def get_total_value(self, obj):
        value = int(obj.value) if obj.value.is_integer() else obj.value
        return value

class DataNameDetailSerializer(serializers.ModelSerializer):
    values = DataValueSerializer(source='datavalue_set', many=True, read_only=True)
    category = serializers.StringRelatedField()


    class Meta:
        model = DataName
        fields = ['name', 'category', 'sumber', 'keterangan', 'created_at', 'updated_at', 'values']

class ProvincialIncidentCountSerializer(serializers.Serializer):
    province_name = serializers.CharField()
    province_area_code = serializers.IntegerField()
    incident_count = serializers.IntegerField()