from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from django.db.models import Count, Sum,Q
from apps.web.models import *
from apps.api.serializers import *
from django.shortcuts import get_object_or_404
import calendar
from django.db.models.functions import Coalesce

#jumlah incident global bulanan, termasuk jumlah korban
class MonthlyIncidentCountView(APIView):
    def get(self, request):
        # Group incidents by month and year, and count them, including casualty and infrastructure data
        incidents_by_month = Incidents.objects.extra(
            select={'month': "strftime('%%m', incident_date)", 'year': "strftime('%%Y', incident_date)"}
        ).values('month', 'year').annotate(
            incident_count=Count('id'),
            total_deaths=Sum('Incident_casualities__num_death'),
            total_injuries=Sum('Incident_casualities__num_injured'),
            infra_damage=Sum('Incident_casualities__infra_damage'),
            infra_destroyed=Sum('Incident_casualities__infra_destroyed'),
            child_total=Sum('Incident_casualities__child_total')
        ).order_by('year', 'month')

        # Format the response
        formatted_response = {}
        for incident in incidents_by_month:
            year = incident['year']
            month_name = calendar.month_name[int(incident['month'])]
            if year not in formatted_response:
                formatted_response[year] = []
            formatted_response[year].append({
                'month': month_name,
                'incidents': incident['incident_count'],
                'total_deaths': incident['total_deaths'] or 0,
                'total_injuries': incident['total_injuries'] or 0,
                'infra_damage': incident['infra_damage'] or 0,
                'infra_destroyed': incident['infra_destroyed'] or 0,
                'child_total': incident['child_total'] or 0
            })

        # Convert the dictionary to a list of dicts
        response_list = [{'year': year, 'data': data} for year, data in formatted_response.items()]

        return Response(response_list, status=status.HTTP_200_OK)

#list jumlah insiden masing-masing kategori
class IncidentsByCategoryViewList(APIView):
    def get(self, request, category_slug):
        # Get the category object based on the slug
        category = get_object_or_404(Options, slug=category_slug,
                                     category=2)  # Assuming category 2 is for incident categories

        # Filter incidents based on the category
        incidents = Incidents.objects.filter(category=category)
        serializer = IncidentsSerializer(incidents, many=True)

        return Response(serializer.data, status=status.HTTP_200_OK)

#jumlah incident per kategori bulanan
class IncidentsByCategoryView(APIView):
    def get(self, request, category_slug):
        # Get the category object based on the slug
        category = get_object_or_404(Options, slug=category_slug,
                                     category=2)  # Assuming category 2 is for incident categories

        # Filter incidents based on the category
        incidents = Incidents.objects.filter(category=category)

        # Group incidents by month and year, and count them, including casualty and infrastructure data
        incidents_by_month = incidents.extra(
            select={'month': "strftime('%%m', incident_date)", 'year': "strftime('%%Y', incident_date)"}
        ).values('month', 'year').annotate(
            incident_count=Count('id'),
            total_deaths=Sum('Incident_casualities__num_death'),
            total_injuries=Sum('Incident_casualities__num_injured'),
            infra_damage=Sum('Incident_casualities__infra_damage'),
            infra_destroyed=Sum('Incident_casualities__infra_destroyed'),
            child_total=Sum('Incident_casualities__child_total')
        ).order_by('year', 'month')

        # Format the response
        formatted_response = {}
        for incident in incidents_by_month:
            year = incident['year']
            month_name = calendar.month_name[int(incident['month'])]
            if year not in formatted_response:
                formatted_response[year] = []
            formatted_response[year].append({
                'month': month_name,
                'incidents': incident['incident_count'],
                'total_deaths': incident['total_deaths'] or 0,
                'total_injuries': incident['total_injuries'] or 0,
                'infra_damage': incident['infra_damage'] or 0,
                'infra_destroyed': incident['infra_destroyed'] or 0,
                'child_total': incident['child_total'] or 0
            })

        # Convert the dictionary to a list of dicts
        response_list = [{'year': year, 'data': data} for year, data in formatted_response.items()]

        return Response(response_list, status=status.HTTP_200_OK)

#data detail dari model Dataname
class DataNameDetailView(APIView):
    def get(self, request, slug):
        data_name = get_object_or_404(DataName, slug=slug)
        serializer = DataNameDetailSerializer(data_name)
        return Response(serializer.data, status=status.HTTP_200_OK)

#jumlah incident tiap provinsi
class ProvincialIncidentCountView(APIView):
    def get(self, request):
        try:
            # Get the DataName object for population with pk=1
            population_data_name = DataName.objects.get(pk=1)

            # Get all provinces (regions with two-digit area codes)
            provinces = Regions.objects.filter(area_code__lt=100, area_code__gte=10)

            result = []
            for province in provinces:
                incident_count = self.count_incidents_recursive(province)

                # Get population data for the province
                try:
                    population = DataValue.objects.get(name=population_data_name, region=province).value
                except DataValue.DoesNotExist:
                    population = None

                if incident_count > 0 or population is not None:
                    result.append({
                        'province_name': province.name,
                        'province_area_code': province.area_code,
                        'incident_count': incident_count,
                        'population': population
                    })

            # Sort the result by province name
            result.sort(key=lambda x: x['province_name'])

            return Response(result, status=status.HTTP_200_OK)

        except DataName.DoesNotExist:
            return Response({"detail": "Population data configuration not found."}, status=status.HTTP_404_NOT_FOUND)
        except Exception as e:
            return Response({"detail": f"An unexpected error occurred: {str(e)}"},
                            status=status.HTTP_500_INTERNAL_SERVER_ERROR)

    def count_incidents_recursive(self, region):
        # Count incidents directly associated with this region
        direct_count = Incidents.objects.filter(location=region).count()

        # Count incidents in sub-provinces
        sub_provinces = region.sub_provinces.all()
        sub_count = sum(self.count_incidents_recursive(sub_province) for sub_province in sub_provinces)

        return direct_count + sub_count